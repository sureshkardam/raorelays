 <header class="header">
        <div class="container">
            <div class="row menu">
                <div class="col-xs-3" style="padding:0px">
                    <div class="nav-logo">
                        <a href="">
                            <img alt="" src="{{ asset('admin/images/rao-logo.jpg') }}" class="img-responsive" width="100%"></a>
                    </div>
                </div>
                <div class="col-xs-9">


                </div>
            </div>
        </div>
    </header>