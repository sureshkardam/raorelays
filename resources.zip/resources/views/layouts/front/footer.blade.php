<footer class="footer-front">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="footer-bottom">
					<p>2020 @ Rao Relays</p>
				</div>
			</div>
		</div>
	</div>
</footer>